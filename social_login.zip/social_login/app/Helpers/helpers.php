<?php

if (!function_exists('site_setting')) {
	function site_setting($key) {
		$site_settings = resolve('App\Models\Sitesetting');
		return $site_settings[$key] ?? '';
	}
}