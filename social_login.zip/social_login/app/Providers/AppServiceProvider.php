<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Config;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Config::set(['services.facebook' => [
            'client_id' => site_setting('github_client_id'),
            'client_secret' => site_setting('github_client_secret'),
            'redirect' => url('login/facebook/callback'),
        ]]);
    }
}
