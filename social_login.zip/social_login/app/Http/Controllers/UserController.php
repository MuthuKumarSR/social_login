<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    public function redirectToProvider()
    {
        return Socialite::driver('facebook')->redirect();
    }

    public function handleProviderCallback()
    {
        $userNode = Socialite::driver('facebook')->user();

        $email = $userNode->getEmail();
        $fb_id = $userNode->getId();

        $user = User::user_facebook_authenticate($email, $fb_id);

        if ($user->count() > 0)
        {
        $user = User::user_facebook_authenticate($email, $fb_id)->first();
        
        $user_id = $user->id;

        if (Auth::loginUsingId($user_id))
        {
            return redirect()->intended('userprofile');
        } else {
            flashMessage('danger', trans('messages.user.login_failed'));
            return redirect(route('login'));
        }
        } 
        else
        {
        $user = User::user_facebook_authenticate($email, $fb_id);

        if ($user->count() > 0) {
            return redirect('user_disabled');
        }
          
        $user_array = array(
        'first_name' => $userNode->getName(),
        'last_name' => $userNode->getNickname(),
        'email' => $email,
        'key_id' => $userNode->getId(),
        'source' => "fb",
        'user_image' => "https://graph.facebook.com/" . $userNode->getId() . "/picture?type=large",
        );
        Session::put('user_data', $user_array);
        return redirect('signup_user');
        }

        $users = User::where('id', $user_id)->first();

        if (@$users->status != 'Inactive') {
        if (Auth::loginUsingId($user_id))
        {
            return redirect()->intended('home');
        } else {
            flashMessage('danger', trans('messages.user.login_failed'));
            return redirect(route('login'));
        }
        } 
        else
        {
            return redirect('user_disabled');
        }

    }
}
