@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Login') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('login') }}">
                        @csrf

                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end">{{ __('Email Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                                    <label class="form-check-label" for="remember">
                                        {{ __('Remember Me') }}
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6 offset-md-4">
                                <a href="{{ url('login/facebook') }}">
                                    <div class="form-check">
                                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHwAAAB8CAMAAACcwCSMAAAAY1BMVEUYd/L///8Ab/HI2PsAcfIAbfEAa/ERdfLw9P4AZfE9gvOYtvf6+//B0/rO3PsGc/Kjv/hclfXf6PwwffKbu/hYkPS60PqNsffo7/1Mi/TU4fxxofYAW/B4pvaqxPlIhfNpmfXOMSqSAAAFKUlEQVRogcWb6ZaqMAyAS6cFBpGyyOo44/s/5QUUWeyStPXc/PQgH92SNAsJ8BIPTd5eiz4hoyR9cW3zZogtXkSQ3CwviGCcMSGiaIJHkRBs/EGQIs+QX4CBl3ldUS7IDD1KRASnVZ2Xn4B3l5pzKXb3CZzXl84zvLmH1Eh+8ml4b/zB05yFQPKTH7I89QKPW0ox5IdQ2pp3nwmeXghDjfo1ekYuptEb4E0S2pAfEiaGtdfCuwK31m+jDwvtztfBT6FwQU8iwpMVvOu5K3oS3qsHr4Q3wnnYDxFCufIq+AmqU8wSUdXUK+CFlylfhBcIeJwwn2xCWCLVODJ46Wu5VxFCZu0k8EFuM90kIgME/hG2nP4GLz/DnuhvM3+Ex+JD7JEujrvuCE+877VVRKKHF57P2F5YoYOfLHWLEDxchNPJr5UvHj+p4Y2FyzJ6DbTqb/l5KEcZsvPv6Vb/VYRK55A2Knhns9kou3692624zFoZPRLbZ7fwHr/ZuPhV+UpnqQ8kejkcv+CCXhRkJXy37Cu8Q3trOj9BCSfh+qcVXmAnPbxqvVMVXKzn7QVvsAOnNx1aDSfha8cv8DRB7nR217PV8ChZZmyBX5ADj/5MNwIlnITLNn3CYxx6nHSJeYbCCYl3cKlG0LFbE1sHZ+0WniJ91YiZb4EaeETTDTxHKnVhHrh22mm+gWMN6Tcg+KKDE7bCsWd8p6Ct4I+zPsPvyDNOf13h0X2Bo7U6U56ztCuHp1y0dmrW8BP8gtxukVCgy9sfXT0a7TtmezjBa+SsR4olv37DvZGofsBLrB1nUpOSVqgJ5OUMz7FwnkvHjVu86SUEP+uEy277GdYy1RM8rpBsws+ygWN9kSoe4RnaX+ZfshXHvoVmIxy95IRK4Pj75bjoBO+7SeH4+Rt9ORJg/ySHf1lcdgJicSf2Ax9vzCTD30s9jZxlpMFfTD3BeUPy/zfynGBdR4/wlqA1kze4uBL8MfcGL0iPDwh4gkc9wd7RPMIT2GN7kRmWL354CP0tKnaV7KTK3uHZ4ZkENiyz0DaNdyK5oB6eiGMLzSmH65I0KgF5NoANZwU3uwnjhgMcNSv4zag/xqMGUDJWcHNQb1QyAPVqA0/Nu31UrwDDYgPvzD7daFgAJtUGDvDpRpMKcCZs4IDXjs7E8JmRA1aTDRAH0gZuPkSTAwlwnW3g5rdOrjPgGy3gqXnW50uDWQ9awEvzZp+vS+ZDYQFvANs4A12RLeAA7TFfkc3BAQs4wKzUsLAIOwXpTmS4/QNms/IMi5gDQvR7Jz+SyMT5Z/eI2U4/A0LooIwP73UJhaGDgD7gryAgNvzpA/4Kf2IDvx7ga+AXG/L2AN+EvJHBfg/wTbAfmeZwh+/SHLgEjzN8n+DBpbac4fvUFi6p5z7t+6QeKp3pCj+mM1GJXEf4eyIXc9Yd4e8pbEzy3g0uS94jNLwbXFq2AC/YcILLCzbgpSoucFWpCrhIxwGuLtKBlic5wNXlSdBlt4frCrOAJWnWcH1JGqwYzxZuKsYDlSFaws1liJAEmR0cUIAJKT21goNKTwF0Gziw6NZcbmwBB5cbGwut8XBEoXVgKDFHw1El5oG+uB4JRxfXa9sKcHCLtgJdQwUKbtVQEahbSRBw21aSQNlEA4a7NNEEivYhKNytfSiQN06B4B4apwJZyxgE7qVlbJJjs5wR7q9ZbpZdm6Ae7rlNcJZNg6QG/pEGyVmW1lB5IveTraEPmZtiQxk8/HBT7CKdhBGD53oj/wCalUlroJdLnwAAAABJRU5ErkJggg==">
                                    </div>
                                </a>    
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Login') }}
                                </button>

                                @if (Route::has('password.request'))
                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
